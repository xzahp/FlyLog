<?php
/**
 * FlyLog - 轻量级博客系统（致敬 Z-Blog）
 * 纯原生 PHP + MySQL，无任何框架
 * -----------------------------------------------
 * 数据库配置：修改下面四个常量即可（首次使用请先运行 install.php）
 * 安全约定：所有进入 SQL 的用户输入一律经过 mysqli_real_escape_string()
 *           或 (int) 强转；全站统一 UTF-8
 * -----------------------------------------------
 * V1.01 变更：新增 FLYLOG_VERSION 版本号、fly_len() 长度助手、
 *             fly_session_cookie_params() 会话 cookie 加固参数
 */

define('FLYLOG_VERSION', '1.01'); // 当前版本号（前台/后台页脚展示）

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'flylog');

// 关闭 mysqli 异常模式，统一用「返回值 + connect_errno/error」判断，保证报错友好
mysqli_report(MYSQLI_REPORT_OFF);

// 建立 MySQL 连接（mysqli）
$conn = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_errno) {
    die('数据库连接失败（错误码 ' . $conn->connect_errno . '）：' . $conn->connect_error
        . '<br>如果是第一次使用，请先访问 <a href="install.php">install.php</a> 完成安装。');
}
// 全站 UTF-8（utf8mb4 完整支持中文与 Emoji）
if (!$conn->set_charset('utf8mb4')) {
    die('设置字符集 utf8mb4 失败：' . $conn->error);
}

/**
 * 输出转义，防 XSS
 */
function fly_e($str)
{
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

/**
 * 生成摘要：去标签、压缩空白、按字符安全截断
 */
function fly_excerpt($text, $len = 120)
{
    $text = trim(preg_replace('/\s+/u', ' ', strip_tags((string)$text)));
    if (function_exists('mb_substr')) {
        return mb_substr($text, 0, $len, 'UTF-8');
    }
    return substr($text, 0, $len);
}

/**
 * V1.01 新增：安全取字符串长度
 * 优先按字符数（UTF-8），无 mbstring 扩展时退化为字节数
 */
function fly_len($str)
{
    return function_exists('mb_strlen') ? mb_strlen((string)$str, 'UTF-8') : strlen((string)$str);
}

/**
 * V1.01 新增：后台会话 cookie 加固参数（HttpOnly + SameSite=Lax）
 * 用法：session_start() 之前先 session_set_cookie_params(fly_session_cookie_params())
 * 说明：站点以 HTTP 部署，secure 固定为 false，避免 cookie 不发导致登录不上
 */
function fly_session_cookie_params()
{
    return array(
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => false,
        'httponly' => true,
        'samesite' => 'Lax',
    );
}
